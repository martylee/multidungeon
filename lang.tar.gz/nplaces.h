/*
 * This file does not correspond to a .c file.  It's just a place for the
 * NPLACES #define, because this has to be shared by client and server.
 */

#define NPLACES 16
