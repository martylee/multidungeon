#define PROTOCOL_VERSION 1

#define MAXHANDLE 80  /* maximum permitted handle size, not including \0 */
