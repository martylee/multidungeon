extern int thing_place[];  /* where each thing is */
extern int n_thing_place;
