/*
 * Global definitions.  Put as little as possible in this file.  However,
 * anything used by most .h files (cf .c files) goes here.
 */

#define NDIRECTIONS 6
